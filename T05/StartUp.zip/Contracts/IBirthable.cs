﻿namespace T05.Contracts
{
    public interface IBirthable
    {
        string Birthdate { get; set; }
    }
}
