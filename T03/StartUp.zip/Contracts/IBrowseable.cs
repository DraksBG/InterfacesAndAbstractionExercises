﻿namespace T03.Contracts
{
    public interface IBrowseable
    {
        string Browse(string url);
    }
}
