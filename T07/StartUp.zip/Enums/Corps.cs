﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T07.Enums
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
