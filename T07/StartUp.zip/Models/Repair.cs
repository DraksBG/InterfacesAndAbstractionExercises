﻿using System;
using System.Collections.Generic;
using System.Text;
using T07.Contracts;

namespace T07.Models
{
    public class Repair : IRepair
    {
        public Repair(string partName, int hoursWorked)
        {
            this.PartName = partName;
            this.HoursWorked = hoursWorked;
        }

        public string PartName { get; }
        public int HoursWorked { get; }

        public override string ToString() => $"Part Name: {this.PartName} Hours Worked: {this.HoursWorked}";
    }
}
