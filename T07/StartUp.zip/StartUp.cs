﻿using System;
using T07.Core;

namespace T07
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
