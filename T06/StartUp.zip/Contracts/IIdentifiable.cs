﻿namespace T04.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; set; }
    }
}
